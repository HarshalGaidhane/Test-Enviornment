﻿using NewsPaperPublishing.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsPaperPublishing.Models
{
    public class NewsSource
    {
        public List<SourceEntity> GetNewsSource()
        {
            try
            {
                List<SourceEntity> lstSource = new List<SourceEntity>();
                lstSource.Add(new SourceEntity 
                { 
                    SourceId = 1, 
                    SourceType = "Internal",
                    SourceNewsPriority = "Medium", 
                    NewsSourceName = "Internal News Source",
                    CategoryId=1,
                    CategoryType = "Technology & Trend",
                    NewsHeadLine = "This new ransomware is targeting Windows and Linux PCs with a unique attack Good." +
                    "I was getting tired of all the old attack methods", 
                    Date = DateTime.Today });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 2,
                    SourceType = "External",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Google News",
                    CategoryId=2,
                    CategoryType = "Political",
                    NewsHeadLine= "Follow up on COVID laws in the UK I never broke the law! I am the law!",
                    Date= DateTime.Today});
                lstSource.Add(new SourceEntity
                {
                    SourceId = 3,
                    SourceType = "External",
                    SourceNewsPriority = "Medium",
                    NewsSourceName = "Press Trust Of India",
                    CategoryId=3,
                    CategoryType = "Sports News",
                    NewsHeadLine= "Interesting to see how players deal with new ICC guidelines: Kumar Sangakkara", Date= DateTime.Today});
                lstSource.Add(new SourceEntity
                {
                    SourceId = 4,
                    SourceType = "External",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Press Trust Of India",
                    CategoryId=4,
                    CategoryType = "Travel",
                    NewsHeadLine = "Maldives to reopen for tourists in July, with mandatory health guidelines",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 5,
                    SourceType = "Internal",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Internal News Source",
                    CategoryId=5,
                    CategoryType = "Advertisement",
                    NewsHeadLine = "Sample Advertisement For Class 12 English Writing Skill Section",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 6,
                    SourceType = "External",
                    SourceNewsPriority = "Medium",
                    NewsSourceName = "Google News",
                    CategoryId=6,
                    CategoryType = "Advertisement",
                    NewsHeadLine = "Microsoft starts notifying users if Windows 10 2004 is blocked Although" +
                    " you do need to go to Windows Update to see it, so let's call it Windows Roulette?",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 7,
                    SourceType = "Internal",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Internal News Source",
                    CategoryId=7,
                    CategoryType = "Technology",
                    NewsHeadLine = "A new device can produce electricity using shadows Who knows what power lurks in the shadows ? ",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 8,
                    SourceType = "External",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Google News",
                    CategoryId=8,
                    CategoryType = "Developer",
                    NewsHeadLine = "C# steps up programming language popularity ladder Or art thou base, common and popular",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 9,
                    SourceType = "External",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Google News",
                    CategoryId=9,
                    CategoryType = "Science",
                    NewsHeadLine = "Smart molecules could be key to computers with 100-times bigger memories You just " +
                    "need a handy scanning tunneling microscope(as most households now have)",
                    Date = DateTime.Today
                });
                lstSource.Add(new SourceEntity
                {
                    SourceId = 10,
                    SourceType = "External",
                    SourceNewsPriority = "High",
                    NewsSourceName = "Goole News",
                    CategoryId =10,
                    CategoryType = "Indusrty News",
                    NewsHeadLine = "Windows 10: Microsoft now credits maker of package manager it 'copied' – but offers " +
                    "no apology The more things change, the more they continue to be the same",
                    Date = DateTime.Today
                });
                return lstSource;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<CategoryType> GetNewsCategory()
        {
            try
            {
                List<CategoryType> lstCatType = new List<CategoryType>();
                lstCatType.Add(new CategoryType { CatId = 1, CatType = "Political" });
                lstCatType.Add(new CategoryType { CatId = 2, CatType = "Sports" });
                lstCatType.Add(new CategoryType { CatId = 3, CatType = "Travel" });
                lstCatType.Add(new CategoryType { CatId = 4, CatType = "Advertisements" });
                return lstCatType;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public List<SourceEntity> RegisterNewsSource()
        //{

        //}

    }
}