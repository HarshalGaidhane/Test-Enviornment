﻿using NewsPaperPublishing.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using System.Web.UI;
using NewsPaperPublishing.Entity;

namespace NewsPaperPublishing.Controllers
{
    public class RegisterNewsController : Controller
    {
        // GET: RegisterNews
        /// <summary>
        /// This action method to get list of Newssources
        /// </summary>
        /// <returns></returns>
        public ActionResult AllNewsComponent(int? page)
        {
            try
            {
                int pageSize = 8;
                int pageNumber = 1;
                pageNumber = page.HasValue ? Convert.ToInt32(page) : 1;
                var returnList = new NewsSource().GetNewsSource();
                //var result = returnList.Where(a => a.SourceNewsPriority == "High").Where(a => a.CategoryId != 5);
                return View(returnList.ToPagedList(pageNumber, pageSize));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// This action method for All news with type source and categories
        /// </summary>
        /// <returns></returns>
        public ActionResult NewsComponentwithoutAdvertisement(int? page)
        {
            try
            {
                int pageSize = 8;
                int pageNumber = 1;
                pageNumber = page.HasValue ? Convert.ToInt32(page) : 1;
                var returnList = new NewsSource().GetNewsSource();
                var result = returnList.Where(a => a.SourceNewsPriority == "High").Where(a => a.CategoryId != 5);
                return View(result.ToPagedList(pageNumber, pageSize));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ActionResult RegisterNewsSource ()
        {
            try 
            {
                SourceEntity objSource = new SourceEntity();
                objSource.SourceId = 11;
                objSource.SourceType = "External";
                objSource.SourceNewsPriority = "High";
                objSource.NewsSourceName = "Google News";
                objSource.CategoryId = 11;
                objSource.CategoryType = "Enviormental";
                objSource.NewsHeadLine = "World Environment Day is celebrated on 5 June every year," +
                    "and is the United Nations' principal vehicle for encouraging awareness and action " +
                    "for the protection of the environment";
                objSource.Date = DateTime.Today;
                return View(objSource);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}