﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace NewsPaperPublishing.Entity
{
    public class SourceEntity
    {
        public int SourceId { get; set; }

        public string SourceType { get; set; }

        public string NewsSourceName { get; set; }

        public string NewsHeadLine { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        public int CategoryId { get; set; }

        public string CategoryType { get; set; }

        public string SourceNewsPriority { get; set; }

        public List<SourceEntity> SourceList { get; set; }
    }
}