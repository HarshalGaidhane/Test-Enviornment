﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsPaperPublishing.Entity
{
    public class CategoryType
    {
        public int CatId { get; set; }

        public string CatType { get; set; }

        public List<CategoryType> CatList { get; set; }
    }
}