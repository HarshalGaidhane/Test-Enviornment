﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NewsPaperPublishing.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewsPaperPublishing.Controllers.Tests
{
    [TestClass()]
    public class RegisterNewsControllerTests
    {
        [TestMethod()]
        public void AllNewsComponentTest()
        {
            Assert.Fail();
        }
    }
}