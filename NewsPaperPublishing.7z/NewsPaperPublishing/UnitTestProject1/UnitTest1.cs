﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using Moq;
using NewsPaperPublishing.Controllers;
using NewsPaperPublishing.Entity;
using NewsPaperPublishing.Models;
using NUnit.Framework;

namespace UnitTestProject1
{
    [TestFixture]
    public class UnitTest1
    {
        RegisterNewsController obj = new RegisterNewsController();

        [Test]
        public void AllNewsComponent()
        {
            var actaul = new NewsSource().GetNewsSource();
            var expected = new List<SourceEntity>() {
                new SourceEntity{
                    SourceId=1,
                    SourceType="External"
                    //Populate other items
                } };
            Assert.IsNotNull(actaul);
            Assert.AreEqual(expected, actaul);
        }

        [Test]
        public void NewsComponentwithoutAdvertisement()
        {
            var actaul = new NewsSource().GetNewsSource();
            var actualResult = actaul.Where(a => a.SourceNewsPriority == "High").Where(a => a.CategoryId != 5);
            var expected = new List<SourceEntity>() {
                new SourceEntity{
                    SourceId=1,
                    SourceType="External"
                    //Populate other items
                } };
            Assert.IsNotNull(actaul);
            Assert.AreEqual(expected,actualResult);
        }

       
    }
}
